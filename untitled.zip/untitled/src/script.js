let producao = 0;
let natureza = 100;
let tecnologia = 0;
let economia = 0;

const producaoTxt = document.getElementById("producao");
const naturezaTxt = document.getElementById("natureza");
const tecnologiaTxt = document.getElementById("tecnologia");
const economiaTxt = document.getElementById("economia");
const mensagem = document.getElementById("mensagem");
const objetos = document.getElementById("objetos");

function atualizar(){

  producaoTxt.innerText = producao;
  naturezaTxt.innerText = natureza;
  tecnologiaTxt.innerText = tecnologia;
  economiaTxt.innerText = economia;

  verificarStatus();
}

function plantar(){

  producao += 15;
  economia += 10;
  natureza -= 5;

  criarObjeto("🌾");

  mensagem.innerText =
    "🌱 A produção agrícola aumentou!";

  atualizar();
}

function usarTecnologia(){

  tecnologia += 10;
  producao += 20;
  economia += 15;
  natureza -= 2;

  criarObjeto("🤖");

  mensagem.innerText =
    "🤖 Tecnologia aplicada no campo!";

  atualizar();
}

function preservar(){

  natureza += 15;

  criarObjeto("🌳");

  mensagem.innerText =
    "🌳 Você preservou o meio ambiente!";

  atualizar();
}

function energiaLimpa(){

  tecnologia += 5;
  natureza += 10;
  economia += 5;

  criarObjeto("☀");

  mensagem.innerText =
    "☀ Energia limpa instalada na fazenda!";

  atualizar();
}

function criarObjeto(emoji){

  const item = document.createElement("div");

  item.classList.add("objeto");

  item.innerText = emoji;

  item.style.left =
    Math.random() * 80 + "%";

  objetos.appendChild(item);
}

function verificarStatus(){

  if(natureza <= 0){

    mensagem.innerText =
      "❌ O meio ambiente foi destruído!";

  }

  if(producao >= 100 &&
     tecnologia >= 50 &&
     natureza >= 50){

    mensagem.innerText =
      "🏆 Parabéns! Você criou um Agro Forte e Sustentável!";
  }
}

atualizar();